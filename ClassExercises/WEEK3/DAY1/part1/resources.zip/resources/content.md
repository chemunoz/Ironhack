Ruby

Ruby is a dynamic, reflective, object-oriented, general-purpose programming language. It was designed and developed in the mid-1990s by Yukihiro "Matz" Matsumoto in Japan. Wikipedia


Ruby on Rails

Rails is a model–view–controller (MVC) framework, providing default structures for a database, a web service, and web pages.  Rails emphasizes the use of CoC and DRY. Wikipedia

HTML5 &amp CSS3

Along with CSS, HTML is a cornerstone technology, used by most websites to create visually engaging webpages, user interfaces for web applications, and for many mobile applications. Wikipedia


JavaScript

JavaScript is prototype-based with first-class functions, making it a multi-paradigm language, supporting object-oriented,[8] imperative, and functional programming styles. Wikipedia